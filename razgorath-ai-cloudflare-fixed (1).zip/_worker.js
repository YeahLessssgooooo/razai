const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SYSTEM = {
  study: "You are RAZGORATH AI Study Mode. Help students understand school subjects clearly and accurately. Explain step by step when useful. Keep explanations age-appropriate and concise.",
  gaming: "You are RAZGORATH AI Gaming Mode. Help with games, gaming PCs, settings, performance, Minecraft, Valorant, and general gaming questions. Give practical, safe advice and clearly distinguish estimates from confirmed facts.",
  general: "You are RAZGORATH AI, a helpful personal AI assistant. Be clear, useful, concise, and honest about uncertainty.",
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...CORS, "Content-Type": "application/json; charset=utf-8" },
  });
}

function sse(text) {
  return new Response(`data: ${JSON.stringify({ text })}\n\n`, {
    status: 200,
    headers: {
      ...CORS,
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      "X-Accel-Buffering": "no",
    },
  });
}

async function handleChat(request, env) {
  if (!env.GEMINI_API_KEY) {
    return json({
      error: "RAZGORATH AI is not configured yet. Add GEMINI_API_KEY in your Cloudflare environment variables, then redeploy."
    }, 500);
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: "Invalid JSON request." }, 400);
  }

  const messages = Array.isArray(body?.messages) ? body.messages : [];
  const mode = body?.mode || "general";
  if (!messages.length) return json({ error: "No message was provided." }, 400);

  const contents = messages.slice(-20).map((m) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: String(m.content || "").slice(0, 12000) }],
  }));

  const model = "gemini-2.5-flash";
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(env.GEMINI_API_KEY)}`;

  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: SYSTEM[mode] || SYSTEM.general }] },
      contents,
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 1200,
      },
    }),
  });

  if (!response.ok) {
    const raw = await response.text();
    let message = `Gemini API error (${response.status}).`;
    try {
      const parsed = JSON.parse(raw);
      message = parsed?.error?.message || message;
    } catch {}
    return json({ error: message }, 502);
  }

  const result = await response.json();
  const text = result?.candidates?.[0]?.content?.parts?.map((p) => p.text || "").join("")?.trim();
  if (!text) return json({ error: "Gemini returned an empty response." }, 502);

  return sse(text);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/api/chat") {
      if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
      if (request.method !== "POST") return json({ error: "Method not allowed." }, 405);
      try {
        return await handleChat(request, env);
      } catch (error) {
        console.error("RAZGORATH /api/chat error", error);
        return json({ error: error?.message || "RAZGORATH AI could not process the request." }, 500);
      }
    }

    // Let Cloudflare serve the normal website files.
    return env.ASSETS.fetch(request);
  },
};
